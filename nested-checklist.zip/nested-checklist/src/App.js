import React from 'react';
import Checklist from './components/Checklist';
import { ChecklistProvider } from './context/ChecklistContext';

function App() {
  return (
    <ChecklistProvider>
      <div>
        <h1>Nested Checklist Application</h1>
        <Checklist />
      </div>
    </ChecklistProvider>
  );
}

export default App;
