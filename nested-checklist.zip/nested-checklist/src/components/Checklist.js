import React, { useState } from 'react';
import useChecklist from '../hooks/useChecklist';
import ChecklistItem from './ChecklistItem';

const Checklist = () => {
  const { checklists, addItem } = useChecklist();
  const [newItem, setNewItem] = useState('');

  const handleAddItem = () => {
    addItem({ id: Date.now(), text: newItem, completed: false, children: [] });
    setNewItem('');
  };

  return (
    <div>
      <input
        type="text"
        value={newItem}
        onChange={(e) => setNewItem(e.target.value)}
        placeholder="Add new checklist item"
      />
      <button onClick={handleAddItem}>Add Item</button>

      {checklists.map((item) => (
        <ChecklistItem key={item.id} item={item} />
      ))}
    </div>
  );
};

export default Checklist;
