import React, { useState } from 'react';
import useChecklist from '../hooks/useChecklist';

const ChecklistItem = ({ item }) => {
  const { updateItem, deleteItem } = useChecklist();
  const [newChild, setNewChild] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  const handleToggle = () => updateItem({ ...item, completed: !item.completed });
  
  const handleAddChild = () => {
    const updatedItem = {
      ...item,
      children: [...item.children, { id: Date.now(), text: newChild, completed: false, children: [] }]
    };
    updateItem(updatedItem);
    setNewChild('');
  };

  return (
    <div style={{ paddingLeft: '20px' }}>
      <input
        type="checkbox"
        checked={item.completed}
        onChange={handleToggle}
      />
      {isEditing ? (
        <input
          value={item.text}
          onChange={(e) => updateItem({ ...item, text: e.target.value })}
          onBlur={() => setIsEditing(false)}
        />
      ) : (
        <span onDoubleClick={() => setIsEditing(true)}>{item.text}</span>
      )}
      <button onClick={() => deleteItem(item.id)}>Delete</button>

      <div>
        <input
          type="text"
          value={newChild}
          onChange={(e) => setNewChild(e.target.value)}
          placeholder="Add nested item"
        />
        <button onClick={handleAddChild}>Add Sub-item</button>
      </div>

      {item.children.map((child) => (
        <ChecklistItem key={child.id} item={child} />
      ))}
    </div>
  );
};

export default ChecklistItem;
