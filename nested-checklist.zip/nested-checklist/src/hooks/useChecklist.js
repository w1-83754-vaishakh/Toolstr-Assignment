import { useContext } from 'react';
import ChecklistContext from '../context/ChecklistContext';

const useChecklist = () => {
  const { state, dispatch } = useContext(ChecklistContext);

  const addItem = (item) => dispatch({ type: 'ADD_ITEM', payload: item });
  const updateItem = (item) => dispatch({ type: 'UPDATE_ITEM', payload: item });
  const deleteItem = (id) => dispatch({ type: 'DELETE_ITEM', payload: id });

  return {
    checklists: state,
    addItem,
    updateItem,
    deleteItem,
  };
};

export default useChecklist;
